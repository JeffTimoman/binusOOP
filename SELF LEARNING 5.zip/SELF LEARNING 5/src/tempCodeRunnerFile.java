
        ArrayList<Integer> ruth = new ArrayList<Integer>();
        ruth.add(1);